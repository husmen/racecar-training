#!/usr/bin/python
# -*- coding: utf-8 -*-

			
import numpy as np
import os 
import time


import rospy
from sensor_msgs.msg import Image

import cv2
from cv_bridge import CvBridge, CvBridgeError

import rospkg
import sys
import rospy


def talker():
    
    pub = rospy.Publisher('/cam_frame', Image, queue_size=1)
    rospy.init_node('publisher', anonymous=True)
    #cam = cv2.VideoCapture(1)
    while not rospy.is_shutdown():
        try:
            #meta, frame = cam.read()
            frame = cv2.imread("img2.jpg")
	    msg_frame = CvBridge().cv2_to_imgmsg(frame)

            pub.publish(msg_frame)
	    print ("Resim Gonderildi")
   
            time.sleep(0.1)
		    
	
        except Exception as e:
            print("Error : ",e)


if __name__ == '__main__':

    try:
        talker()
    except rospy.ROSInterruptException:
        pass

    rospy.spin()
