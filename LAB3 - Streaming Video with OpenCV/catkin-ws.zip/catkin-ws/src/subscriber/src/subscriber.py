#!/usr/bin/python
# -*- coding: utf-8 -*-

import rospy
import cv2


from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
bridge = CvBridge()

def image_callback(msg):
    img = bridge.imgmsg_to_cv2(msg)
    #cv2.imshow('gelen resim', img)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()
    print (img.shape)
   
  

def main():
    global pub_angle
    rospy.init_node('subscriber', anonymous=True)
    rospy.Subscriber("/cam_frame", Image, image_callback, queue_size=1)
    rospy.spin()

if __name__ == '__main__':
    main()


